/**
 * Created by james on 29/10/2016.
 */

define(['require','jsx!layouts/default-layout'],function(require,DefaultLayout) {

    console.log("about-index.jsx has been reached");
    var React = require('react');
    //var DefaultLayout = require('jsx!layouts/default-layout');
    var AboutIndex = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'About Index'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                    <AboutIndexContent />
                </DefaultLayout>
            );
        }
    });

    var AboutIndexContent = React.createClass({
        render: function() {
            return(
            <div>
                <h2>
                    THE CONSOLIDATED STUDIO INDEX, April
                    1893 to June 1962, Vols 1 - 163.
                </h2>
                <p>
                    This consolidated index is derived from the bound
                    volumes of The Studio Magazine of Decorative Art and contains around<i> 70,000 entries.</i>
                </p>
                <p>
                    <h2>History.</h2>The decision to produce a consolidated index was made in the early 1990's and a start was made with
                    some paid help and my family pitching in, with the first target
                    being the first 100 volumes. Each entry was checked against the original indexes
                    and additional information added before finally putting onto the Digital Index
                    Database. This Index was stopped at June 1962, Volume 163, it is intended to extend it
                    in due course.
                </p>
                <p>
                    Each entry has the Volume no., issue no., month/year,
                    page number(s), surname(s), initials & other name(s), Description of entry, type
                    (ie article, illustration, supplement, Book review or competition
                    entry.)
                </p>
                <p>
                    The monthly issue numbers and month/year of publication are a major
                    addition to the Index as they were not included in the original indexes and the details
                    of Competitions running from Vols 1 - 55 are in the process of being extended to show
                    the pseudonym's, full names and addresses of the prize winners.
                </p>
                <p>
                    <h2>Hints on searching the Index by surname.</h2>
                </p>
                <p>
                    <u>You should only enter one surname at a time</u>. In some cases more than one surname will be present in the
                    surname index field - you may enter one surname but receive a result which includes
                    others. If this is the case the index will also have registered the other name(s) as a
                    separate entry - that is, you can search on either surname and you will get a
                    result.
                </p>
                <p>
                    <h2>Hints on searching the Index by Description.</h2>
                </p>
                <p>
                    The Index holds up to 120 characters of description and
                    this can be searched by entering a word or phrase and initiating the search which will
                    find any description that contains your word or phrase (please note that indefinite
                    articles such as 'the', 'or' 'a' etc cannot be used and will invalidate the search).
                    The Phrase or word must be spelt correctly and appear in the description in the same
                    sequence as you enter it.
                </p>
                <p>
                    <u>Please note</u> that for online searching purposes many special characters such as those used in languages have
                    been replaced with the standard character, so if you enter a search with a special
                    character and it returns no results please try again changing any special characters to
                    standard characters. <br/>
                </p>
                <p>
                    If you find any errors or omissions
                    please <a href="http://www.studioindex.co.uk/LinkClick.aspx?link=99&amp;tabid=84&amp;portalid=0&amp;mid=412">CONTACT US</a>.
                </p>
                <p>
                    <h2>Notes on Copyright</h2>
                </p>
                <p>
                    The information used in this index has been compiled
                    afresh and so is copyright in this digital form to studioindex.co.uk and the copyright
                    holders stated at the bottom of each page.
                </p>
                <p>
                    studioindex.co.uk is in
                    the process of individually scanning Volumes 1 - 84 correcting publishing errors as
                    found and where appropriate re-aligning the page numbering to assist searching. They
                    will be available (as completed) in readable form directly from the search result
                    facility - taking you directly to the page. The text or illustration can then be viewed
                    page by page - in addition the text of each volume will be searchable and available to
                    'cut & paste' on a page by page basis.
                </p>
                <p>
                    There will be no extra charge for this
                    service.
                </p>
                <p>
                    Links given to digital images of the original material
                    are given in good faith relying on the fact that they have no known copyright and to be
                    in the public domain, any breeches of copyright are inadvertent and if notified will be
                    investigated and if appropriate remedial action taken.
                </p>
            </div>
            );
        }
    });

    return AboutIndex;
});
