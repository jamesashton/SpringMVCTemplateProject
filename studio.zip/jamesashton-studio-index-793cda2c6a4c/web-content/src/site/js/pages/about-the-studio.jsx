/**
 * Created by james on 29/10/2016.
 */

define(['require','jsx!layouts/default-layout'],function(require,DefaultLayout) {

    console.log("about-the-studio.jsx has been reached");
    var React = require('react');
  //  var DefaultLayout = require('jsx!layouts/default-layout');
    var AboutTheStudio = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'About the Studio'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                    <AboutTheStudioContent />
                </DefaultLayout>
            );
        }
    });

    var AboutTheStudioContent = React.createClass({
        render: function() {
            return(
                <div>
                    <b>The Studio' was undoubtedly one of the greatest and most accomplished of
                        book publishers on Fine and Applied Arts.</b>

                    <p>Our Index of 70,000 entriesgives a unique opportunity to find new
                                                         ways of probing this amazing fund of knowledge</p>

                    <p>To learn more about 'The Studio' and 'Studio International' please go to <a href=
                                       "/LinkClick.aspx?link=97&amp;tabid=93&amp;portalid=0&amp;mid=430">STUDIO
                            LINKS</a></p>

                    <h1><strong>&nbsp;Digest of its history.</strong></h1>

                    <ul>
                        <li>
                            <p>'The Studio' was published monthly from April 1893 (vol. 1, no. 1) to May 1964
                                (vol. 167, no. 853). Volumes 1 - 77 covered a four month period and from Volume
                                78 onwards each volume consisted of 6 monthly issues, the issue numbers being
                                consecutively numbered.</p>
                        </li>

                        <li>
                            <p>'The Studio' was continued as 'Studio International', which was published six
                                times a year from June 1964 (vol. 167, no. 854) to July 1992 (vol. 201, no.
                                1020). A special issue was published in 1993 (numbered vol. 201, no. 1022/1023)
                                as a celebration of the centenary of 'The Studio'.</p>
                        </li>

                        <li>
                            <p>'Studio International' continues as&nbsp;<a href="http://www.studio-international.co.uk/"><strong>Studio International
                                web-site</strong></a>&nbsp;with exhibition reviews and some archival articles</p>
                        </li>

                        <li>
                            <p>Charles Holme, whose family were to run The Studio for around 60 years, had
                                been considering publishing an art magazine with Applied Arts given equal billing
                                to Fine Arts so when a detailed proposal from Art Editor C. Lewis Hinds for such
                                a magazine was put to him, he seized the opportunity.</p>
                        </li>

                        <li>
                            <p>Charles Holmes appointed Gleeson White as the first editor of 'The Studio' and
                                publishing commenced with the first issue in April 1893.</p>
                        </li>

                        <li>
                            <p>Just after WWI Geoffrey Holmes took over the running of 'The Studio' and his
                                sons Rathbone and Bryan continued the family connection until 1954 when the
                                business was sold to Sir Edward Hulton, the publisher of Picture Post.</p>
                        </li>

                        <li>
                            <p>From the earliest years 'The Studio' produced a range of specials covering
                                particular aspects of the Applied Arts, the earliest ones including Modern
                                Photography, Modern Publicity, Children's Books, Bookplates and Bookbinding.</p>
                        </li>

                        <li>
                            <p>In 1906 it introduced the first of its annuals, 'The Yearbook of Decorative
                                Art'. Other important annuals introduced included 'Modern Photography' and
                                'Posters and Publicity' which later became 'Modern Publicity'. They continued to
                                produce Special numbers, Annuals and many one-offs on a wide range of subjects
                                often authored by leading artists and designers such as Bruno Taut on Modern
                                Architecture 1929, Le Corbusier on Aircraft in 1935 and A. Tolmer on The Theory
                                and Practice of Lay-out.</p>
                        </li>
                    </ul>
                </div>
            );
        }
    });

    return AboutTheStudio;
});
