/**
 * Created by james on 29/10/2016.
 */

define([
        'require',
        'jsx!layouts/default-layout',
        'jsx!components/expanding-list'
    ],function(
        require,
        DefaultLayout,
        ExpandingList
    ) {

    console.log("about-index.jsx has been reached");
    var React = require('react');
   // var DefaultLayout = require('jsx!layouts/default-layout');
   // var ExpandingList = require('jsx!components/expanding-list');
    var Faqs = React.createClass({
        faqs: [
            {
                "title": "This is the first FAQ",
                "content": "This is the content for the first FAQ"
            },
            {
                "title": "This is the second FAQ",
                "content": "This is the content for the second FAQ"
            },
            {
                "title": "This is the third FAQ",
                "content": "This is the content for the third FAQ"
            }
        ],
        getDefaultProps: function() {
            return {
                title: 'FAQs!'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                    <ExpandingList data={this.faqs} />
                </DefaultLayout>
            );
        }
    });

    return Faqs;
});
