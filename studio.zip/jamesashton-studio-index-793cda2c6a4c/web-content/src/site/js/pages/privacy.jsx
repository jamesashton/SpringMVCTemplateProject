/**
 * Created by james on 29/10/2016.
 */

define(['require','jsx!layouts/default-layout'],function(require,DefaultLayout) {

    console.log("privacy.jsx has been reached");
    var React = require('react');
    //var DefaultLayout = require('jsx!layouts/default-layout');
    var Faqs = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'Privacy!'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                    <div>Privacy policy
                    </div>
                </DefaultLayout>
            );
        }
    });

    return Faqs;
});
