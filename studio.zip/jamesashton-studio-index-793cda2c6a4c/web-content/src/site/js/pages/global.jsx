define(/*[    'require',
            'jsx!pages/about-the-studio',
            'jsx!pages/about-index',
            'jsx!pages/about-us',
            'jsx!pages/contact-us',
            'jsx!pages/faqs',
            'jsx!pages/index',
            'jsx!pages/register',
            'jsx!pages/search',
            'jsx!pages/admin/index',
            'jsx!pages/admin/users'
    ],*/
    function(
             require /*,
             AboutTheStudio,
             AboutIndex,
             AboutUs,
             ContactUs,
             Faqs,
             Index,
             Register,
             Search,
             AdminIndex,
             AdminUsers*/
    ){

    var React = require('react');
    var ReactDOM = require('react-dom');
    var ReactRouter = require('react-router');
    var Router = ReactRouter.Router;
    var Route = ReactRouter.Route;

    /* User pages */
    var AboutTheStudio = require('jsx!pages/about-the-studio');
    var AboutIndex = require('jsx!pages/about-index');
    var AboutUs = require('jsx!pages/about-us');
    var ContactUs = require('jsx!pages/contact-us');
    var Faqs = require('jsx!pages/faqs');
    var Index = require('jsx!pages/index');
    var Register = require('jsx!pages/register');
    var Search = require('jsx!pages/search');
    var Login = require('jsx!pages/login');

    /* Admin pages */
    var AdminIndex = require('jsx!pages/admin/index');
    var AdminUsers = require('jsx!pages/admin/users');
    var AdminVolumes =  require('jsx!pages/admin/volumes');
    var AdminPages =  require('jsx!pages/admin/pages');

    var browserHistory = ReactRouter.browserHistory;
    var Global = function() {}
    Global.prototype.init = function() {
            //ReactDOM.render(<MainMenu />, document.getElementById('leftMenuHolder'));
            //ReactDOM.render(<MainMenu />, document.getElementById('topMenuHolder'));

            ReactDOM.render(
                <Router history={browserHistory}>
                    <Route path="/" component={Index} />
                    <Route path="/about-the-studio" component={AboutTheStudio} />
                    <Route path="/about-index" component={AboutIndex} />
                    <Route path="/about-us" component={AboutUs} />
                    <Route path="/contact-us" component={ContactUs} />
                    <Route path="/faqs" component={Faqs} />
                    <Route path="/register" component={Register} />
                    <Route path="/search" component={Search} />
                    <Route path="/login" component={Login} />
                    <Route path="/admin/" component={AdminIndex} />
                    <Route path="/admin/home.html" component={AdminIndex} />
                    <Route path="/admin/users.html" component={AdminUsers} />
                    <Route path="/admin/volumes.html" component={AdminVolumes} />
                    <Route path="/admin/pages.html" component={AdminPages} />
                </Router>,
                document.getElementById('main')
            );
    }


    return Global;
});
