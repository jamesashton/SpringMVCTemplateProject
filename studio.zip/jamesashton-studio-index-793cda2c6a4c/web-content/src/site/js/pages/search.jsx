/**
 * Created by james on 29/10/2016.
 */

define(['require','jsx!layouts/default-layout'],function(require,DefaultLayout) {

    console.log("search.jsx has been reached");
    var React = require('react');
   // var DefaultLayout = require('jsx!layouts/default-layout');
    var Search = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'Search'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                </DefaultLayout>
            );
        }
    });
    return Search;
});
