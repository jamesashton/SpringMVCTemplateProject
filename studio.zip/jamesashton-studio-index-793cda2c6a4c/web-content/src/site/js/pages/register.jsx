/**
 * Created by james on 03/07/2016.
 */

define([
    'require',
    'jsx!layouts/default-layout',
    'jsx!components/link-pic',
    'jsx!components/register-steps'
],function(
    require,
    DefaultLayout,
    LinkPic,
    RegisterSteps
){
    console.log("register.jsx has been reached");
    var React = require('react');
    //var LinkPic = require('jsx!components/link-pic');
    //var RegisterForm = require('jsx!components/register-form');

   //var DefaultLayout = require('jsx!layouts/default-layout');
    var Register = React.createClass({
        getDefaultProps: function() {
            return {
              title: 'Register'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                    <div>
                        <RegisterSteps />
                        <LinkPic image="twitter" url="http://www.twitter.com/thestudioindex" text="Follow us on Twitter" />
                    </div>
                </DefaultLayout>
            );
        }
    });

    return Register;

});


