/**
 * Created by james on 29/10/2016.
 */

define(['require','jsx!layouts/default-layout'],function(require,DefaultLayout) {

    console.log("about-us.jsx has been reached");
    var React = require('react');
    //var DefaultLayout = require('jsx!layouts/default-layout');
    var AboutUs = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'About Us'
            };
        },
        render: function () {
            return(
                <DefaultLayout title={this.props.title}>
                    <AboutUsContent />
                </DefaultLayout>
            );
        }
    });

    var AboutUsContent = React.createClass({
        render: function () {
            return (
                <div>
                    <h2>About Us</h2>
                    <h4>Studio Index - A unique resource for researchers of Art & Architecture from 1893 - 1962.</h4>
                    <p><b>Studioindex.co.uk</b> has been set up to make available the first of what we hope will be many
                        useful indexes.</p>
                    <p>This first consolidated index of the Studio Magazine for Vols 1 - 163 was initially compiled and
                        funded for personal use before the decision to make the index available on-line.</p>
                    <p>We are sure that there will be other individuals who have compiled indexes in many fields to help
                        their research and who would be willing to make them available. To this end we have decided to
                        make a small charge for the use of this index to help fund further indexing projects.</p>
                    <p>We hope very soon to add a<b>Studio Yearbook</b> consolidated index to this site and also to
                        provide on-line access to digital images of Volumes 1 - 84 of The Studio Magazine</p>
                    <p>Our end goal is to make available to researchers the most comprehensive Index of Indexes
                        available.</p>
                    <p>If you have an index that you think would be useful to researchers and are willing to make it
                        available on-line please contact us.</p>
                </div>
            );
        }
    });

    return AboutUs;
});
