/**
 * Created by james on 29/10/2016.
 */

define(['require','jsx!layouts/default-layout','jsx!components/login-form'],function(require,DefaultLayout,LoginForm) {

    console.log("index.jsx has been reached");
    var React = require('react');

    var Index = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'Welcome.'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                   <LoginForm />
                </DefaultLayout>
            );
        }
    });

    return Index;
});
