/**
 * Created by james on 03/07/2016.
 */

define([
    'require',
    'jsx!layouts/default-layout',
    'jsx!components/contact-us-form'
],function(
    require,
    DefaultLayout,
    ContactUsForm
) {

    console.log("contact-us.jsx has been reached");
    var React = require('react');
   // var DefaultLayout = require('jsx!layouts/default-layout');
   // var ContactUsForm = require('jsx!components/contact-us-form');
    var ContactUs = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'Contact Us'
            };
        },
        render: function() {
            return(
                <DefaultLayout title={this.props.title}>
                    <ContactUsForm/>
                </DefaultLayout>
            );
        }
    });

    return ContactUs;
});
