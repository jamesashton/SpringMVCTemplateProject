/**
 * Created by james on 29/10/2016.
 */

define(function(require) {

    console.log("admin/index.jsx has been reached");
    var React = require('react');
    var AdminLayout = require('jsx!layouts/admin-layout');
    var Index = React.createClass({
        getDefaultProps: function() {
            return {
                title: 'ADMIN HOME'
            };
        },
        render: function() {
            return(
                <AdminLayout title={this.props.title}>
                </AdminLayout>
            );
        }
    });

    return Index;
});
