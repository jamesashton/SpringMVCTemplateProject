require.config({

    paths: {
        "react":"bower_components/react/react-with-addons",
        "react-dom":"bower_components/react/react-dom",
        "react-router":"vendor/ReactRouter",
        "babel": "bower_components/requirejs-react-jsx/babel-5.8.34.min",
        "jsx": "bower_components/requirejs-react-jsx/jsx",
        "text": "bower_components/requirejs-text/text"
    },

    shim : {
        "react": {
            "exports": "React"
        }
    },

    config: {
        babel: {
            sourceMaps: "inline", // One of [false, 'inline', 'both']. See https://babeljs.io/docs/usage/options/
            fileExtension: ".jsx" // Can be set to anything, like .es6 or .js. Defaults to .jsx
        }
    }


});


require([
    'jsx!pages/global','react','react-dom','react-router']
    ,
    function(Global,React,ReactDOM,ReactRouter) {

     var global = new Global();
        global.init();


        /*
    var pageName = location.pathname.substring(1);
    if(pageName.indexOf(".html") > -1) {
        pageName = pageName.substring(0, pageName.length - 5);
    }
    console.log("PageName: " + pageName);
    var pageObject;

    switch(pageName) {
        case 'contact-us':
            pageObject = new ContactUs();
            break;
        case 'register':
            pageObject = new Register();
            break;
        case 'about-index':
            pageObject = new AboutIndex();
            break;
        case 'about-the-studio':
            pageObject = new AboutTheStudio();
            break;
        case 'about-us':
            pageObject = new AboutUs();
            break;
        case 'faqs':
            pageObject = new Faqs();
            break;
        case 'index':
            pageObject = new Index();
            break;
        case 'search':
            pageObject = new Search();
            break;
        default:
        // index
    }
    if(pageObject) {
        pageObject.init();
        console.log('page.init() has been called');
    };
*/


    console.log("main.js complete");
});
/*
    console.log("loading main.js");
    var contactUs = require('./contact-us.jsx');
    var register = require('./register.jsx');
    var pageName = location.pathname.substring(1);
    console.log("PageName: " + pageName);
    var pageObject;
    switch(pageName) {
        case 'contact-us':
            pageObject = contactUs;
            break;
        case 'register':
            pageObject = register;
            break;
        default:
        // index
    }
    if(pageObject) {
        window.onload = function () {
            pageObject.init();
            console.log('page.init() has been called');
        };
    };
//var className = pageName.substring(0,pageName.indexOf('-')) +  pageName.substr(pageName.indexOf('-')+1,1).toUpperCase() +  pageName.substring(pageName.indexOf('-')+2);

    console.log("main.js complete");
*/
