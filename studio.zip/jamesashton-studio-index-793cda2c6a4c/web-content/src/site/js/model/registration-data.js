/**
 * Created by james on 05/05/2017.
 */
define(function () {

    "use strict";

    function RegistrationData(firstName,lastName,password,email,registrationType,payment) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.email = email;
        this.registrationType = registrationType;
        this.payment = payment;
    }

    return RegistrationData;
});
