/**
 * Created by james on 30/10/2016.
 */
define(['require','jsx!../components/main-menu','jsx!components/title'],function (require, MainMenu, Title) {
    var React = require('react');
    var Link = require('react-router').Link;
    var DefaultLayout = React.createClass({
        propTypes: {
            title: React.PropTypes.string
        },
        render: function() {
            return (
            <div className="page-content">
                <aside className="sidebar-left"><a href="/" className="company-logo"><img src="/img/logo.png" alt="Studio Index" className="company-logo" /></a>
                    <div className="left-menu-holder" id="leftMenuHolder">
                        <div className="sidebar-links">
                            <div className="buttonBackground"><Link to={'/admin/home.html'}>HOME</Link></div>
                            <div className="buttonBackground"><Link to={'/admin/users.html'}>USERS</Link></div>
                            <div className="buttonBackground"><Link to={'/admin/volumes.html'}>VOLUMES</Link></div>
                            <div className="buttonBackground"><Link to={'/admin/pages.html'}>PAGES</Link></div>
                            <div className="buttonBackground"><a onClick={window.loginFormSubmit} href='#'>LOGOUT</a></div>
                            }
                        </div>
                    </div>
                    <div className="search-box">
                        <div className="container-1"><span className="icon"><i className="fa fa-search"></i></span>
                            <input id="search" type="search" placeholder="Search..." />
                        </div>
                    </div><br /><img src="/img/AA_voysey_cover_188px.png" alt="Voysey Cover" className="sidebar-graphic" />
                </aside>
                <div className="main-content">
                    <div className="top-menu-holder" id="topMenuHolder">
                        <div className="sidebar-links">
                            <div className="buttonBackground"><Link to={'/admin/home.html'}>HOME</Link></div>
                            <div className="buttonBackground"><Link to={'/admin/users.html'}>USERS</Link></div>
                            <div className="buttonBackground"><Link to={'/admin/volumes.html'}>VOLUMES</Link></div>
                            <div className="buttonBackground"><Link to={'/admin/pages.html'}>PAGES</Link></div>
                            <div className="buttonBackground"><a onClick={window.loginFormSubmit}  href='#'>LOGOUT</a></div>
                        </div>
                    </div>

                    <div className="white-panel">
                        <Title text={this.props.title} />
                        <hr />
                        {this.props.children}
                    </div>
                    <hr className="footer-seperator"/>
                    <div className="footer-content">
                        <div className="footer-content-left">
                            <p>Copyright [2012-2016] by Norman & James Ashton</p>
                        </div>
                        <div className="footer-content-right">
                            <div className="table-panel">
                                <div className="left-cell"><a href="privacy.html">Privacy Statement</a></div>
                                <div className="middle-cell"><a href="term.html">Terms of Use</a></div>
                                <div className="right-cell"><a href="contact-us">Contact Us</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            );
        }
    });
    return DefaultLayout;
});

/*
 render: function() {
 return (
 <div>
 <Link to={''} className="link-blue">HOME</Link>|<Link to={'register'} className="link-red">REGISTER</Link>|<Link to={'about-us'} className="link-red">ABOUT US</Link>
 <hr />
 <Title text={this.props.title} />
 {this.props.children}
 </div>
 );
 }*/
