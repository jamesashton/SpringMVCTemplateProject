/**
 * Created by james on 06/05/2017.
 */
define(function (require) {

    var React = require('react');

    var LoginForm = React.createClass({
        render: function() {
            return(<table>
                        <tr>
                            <td>User:</td>
                            <td><input ref='email' type='text' defaultValue={this.props.email}  /></td>
                        </tr>
                        <tr>
                            <td>Password:</td>
                            <td><input type='password' name='password'  defaultValue={this.props.password}/></td>
                        </tr>
                        <tr>
                            <td colspan='2'><input name="submit" type="submit"
                                                   value="submit" /></td>
                        </tr>
                    </table>);
        }
    });

    return LoginForm
});
