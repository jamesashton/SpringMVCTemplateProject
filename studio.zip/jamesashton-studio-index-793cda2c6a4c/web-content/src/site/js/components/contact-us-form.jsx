/**
 * Created by james on 05/08/2016.
 */

define(function(require) {

    var React = require('react');

    var ContactUsForm = React.createClass({
        render:function(){
            return (
                <div className="contact-us-form">
                    <div className="form-item">
                        <div className="form-label">Name</div>
                        <div className="form-value"><input id="contactUsNameInput" className="form-text-input" /></div>
                    </div>
                    <div className="form-item">
                        <div className="form-label">Email</div>
                        <div className="form-value"><input id="contactUsEmailInput" className="form-text-input" /></div>
                    </div>
                    <div className="form-item">
                        <div className="form-label">Message</div>
                        <div className="form-value"><textarea id="contactUsMessageTextArea" className="form-text-input"></textarea></div>
                    </div>
                    <div className="form-item">
                        <button type="button" className="form-submit-button">Send</button>
                    </div>
                </div>
            );
        }
    });

    return ContactUsForm;
});
