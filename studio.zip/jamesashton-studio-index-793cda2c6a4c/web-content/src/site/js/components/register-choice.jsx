/**
 * Created by james on 05/08/2016.
 */

define(function(require) {

    var React = require('react');
    var RegisterChoice = React.createClass({
        render:function(){
            return (
                <div className="contact-us-form">
                    <div className="form-item">
                        <div className="form-label">Registration Type</div>
                        <div className="form-value"><input ref="registrationType" type="text" className="form-text-input" defaultValue={ this.props.registrationData.registrationType} /></div>
                    </div>

                    <div className="form-item">
                        <button type="button"  onClick={ this.saveAndContinue } className="form-submit-button">Continue</button>
                    </div>
                </div>
            );
        },
        saveAndContinue: function(e) {
            e.preventDefault();

            var data = {
                registrationType: this.refs.registrationType.value
            };

            this.props.saveValues(data);
            this.props.nextStep();
        }
    });

    return RegisterChoice;
});
