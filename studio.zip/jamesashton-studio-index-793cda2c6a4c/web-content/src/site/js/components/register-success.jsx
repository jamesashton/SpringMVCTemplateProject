/**
 * Created by james on 05/08/2016.
 */

define(function(require) {

    var React = require('react');
    var LoginForm = require('jsx!./login-form')
    var RegisterSuccess = React.createClass({
        render:function(){
            return (
                <div>
                    <h2>Success!</h2>
                    You have now been registered with us. <br />
                    Please login to continue:
                    <LoginForm email={this.props.registrationData.email} password={this.props.registrationData.password}/>
                </div>
            );
        }
    });

    return RegisterSuccess;
});
