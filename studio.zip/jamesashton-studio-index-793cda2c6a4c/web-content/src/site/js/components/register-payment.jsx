/**
 * Created by james on 05/08/2016.
 */

define(function(require) {

    var React = require('react');
    var RegisterPayment = React.createClass({
        render:function(){
            return (
                <div className="contact-us-form">
                    <div className="form-item">
                        <div className="form-label">Payment</div>
                        <div className="form-value"><input ref="payment" type="text" className="form-text-input" defaultValue={ this.props.registrationData.payment } /></div>
                    </div>
                    <div className="form-item">
                        <button type="button" onClick={ this.saveAndContinue } className="form-submit-button">Continue</button>
                    </div>
                </div>
            );
        },
        saveAndContinue: function(e) {
            e.preventDefault();

            var data = {
                payment: this.refs.payment.value
            }
            this.props.saveValues(data);
            this.props.submitRegistration(data);
            this.props.nextStep();
        }

    });

    return RegisterPayment;
});
