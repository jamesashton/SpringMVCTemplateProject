/**
 * Created by james on 22/07/2016.
 */
define(function(require) {

    var React = require('react');
    var LinkPic = React.createClass({
        render:function(){
            return (
                <a href={this.props.url} target="_blank" className="link-pic-link">
                    <div className="link-pic-bg">
                        <LinkPicImage image={this.props.image} />
                        <div className="link-pic-label"><span className="link-pic-text">{this.props.text}</span></div>
                    </div>
                </a>
            );
        }
    });
    var LinkPicImage = React.createClass({
        render: function() {
            return (
                <img className="link-pic-image" src={"img/" + this.props.image + "/default.png"} />
            );
        }
    });

    return LinkPic;
});

