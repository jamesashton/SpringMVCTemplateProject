/**
 * Created by james on 04/05/2017.
 * see https://www.viget.com/articles/building-a-multi-step-registration-form-with-react
 */
define(function (require) {

    var React = require('react');

    var RegistrationData = require('../model/registration-data');

    var RegisterForm = require('jsx!./register-form');
    var RegisterChoice = require('jsx!./register-choice');
    var RegisterPayment = require('jsx!./register-payment');
    var RegisterSuccess = require('jsx!./register-success');
    var RegisterFail = require('jsx!./register-fail');

    var registrationData = new RegistrationData(null,null,null,null,null,null);

    var RegisterSteps = React.createClass({
        getInitialState: function(){
            return { step: 1 }
        },
        save: function(regData) {
            return function() {
               registrationData = Object.assign({},registrationData,regData)
            }()
        },
        next: function() {
            this.setState({
                step: this.state.step + 1
            })
        },
        previous: function() {
            this.setState({
                step : this.state.step - 1
            })
        },
        submitRegistration: function() {
            this.setState({
                step : 4
            })
        },
        render: function() {
            switch (this.state.step) {
                case 1:
                    return <RegisterForm    registrationData={registrationData}
                                            nextStep={this.next}
                                            saveValues={this.save} />
                case 2:
                    return <RegisterChoice registrationData={registrationData}
                                           nextStep={this.next}
                                           previousStep={this.previous}
                                           saveValues={this.save} />
                case 3:
                    return <RegisterPayment registrationData={registrationData}
                                            previousStep={this.previous}
                                            saveValues={this.save}
                                            submitRegistration={this.submitRegistration}/>
                case 4:
                    return <RegisterSuccess registrationData={registrationData}  />
                case 5:
                    return <RegisterFail registrationData={registrationData} />
            }
        }

    });


    return RegisterSteps;
});
