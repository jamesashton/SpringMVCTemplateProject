define(function (require) {

    var React = require('react');


    var ExpandingList = React.createClass({
        getInitialState: function(itemList){
            return { openItemIndex: -1 }
        },
        createItems: function(itemList){
            var items = itemList.map(this.createItem)
            return items;
        },
        createItem: function(item, index){
            var openStatus = (index === this.state.openItemIndex);
            /* Remember to add a 'key'. React wants you to add an identifier when you instantiate a component multiple times */
            return <ListItem key={index} data={item} toggleOne={this.toggleOne} open={openStatus} />
        },
        toggleOne: function(id){
            if(this.state.openItemIndex === id){
                this.setState({openItemIndex: -1});
            } else {
                this.setState({openItemIndex: id});
            }
        },
        render: function() {
            var items = this.createItems(this.props.data);
            return (
                <div className="expandingList">
                    {items}
                </div>
            );
        }
    });

    var ListItem = React.createClass({
        getInitialState: function(){
            return {
                open: false
            }
        },
        toggleContent: function(){
            this.setState({
                open: !(this.state.open)
            });
        },
        getContentToggleHeight: function(){
            if(this.state.open){
                return "3em"
            } else {
                return "0"
            }
        },
        render: function() {
            var style = { height: this.getContentToggleHeight() };
            return (
                <div className={"item"}>
                    <h2 className="itemTitle" onClick={this.toggleContent}>{this.props.data.title}</h2>
                    <p className="itemContent" style={style}>{this.props.data.content}</p>
                </div>
            );
        }
    })

    return ExpandingList;
})
