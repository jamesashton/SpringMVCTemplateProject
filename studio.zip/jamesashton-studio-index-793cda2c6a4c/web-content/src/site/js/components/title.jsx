/**
 * Created by james on 27/10/2016.
 */
define(function (require) {

    var React = require('react');

    var Title = React.createClass({
        render: function() {
            return (
              <div className="page-title"><h1>{this.props.text}</h1></div>
            );
        }

    });
    return Title;
});
