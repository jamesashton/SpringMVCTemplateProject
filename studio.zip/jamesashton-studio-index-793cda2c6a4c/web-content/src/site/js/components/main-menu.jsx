/* Note that this page doesn't work - temporarily moved the menu to default-layout but this shoudl be reinstated*/

define(function(require) {
    var React = require('react');
    var ReactDOM = require('react-dom')
    var Babel = require('babel');
    var Link = require('react-router').Link;
/*
    var AboutTheStudio = require('jsx!../pages/about-the-studio');
    var AboutIndex = require('jsx!../pages/about-index');
    var AboutUs = require('jsx!../pages/about-us');
    var ContactUs = require('jsx!../pages/contact-us');
    var Faqs = require('jsx!../pages/faqs');
    var Index = require('jsx!../pages/index');
    var Register = require('jsx!../pages/register');
    var Index = require('jsx!../pages/index');
    var Search = require('jsx!../pages/search');


*/
    var MainMenu = React.createClass({
        render:function() {
            return (
                <div className="sidebar-links">
                    <div className="buttonBackground"><Link to={''} className="link-blue">HOME</Link></div>
                    <div className="buttonBackground"><Link to={'register'} className="link-red">REGISTER</Link></div>
                    <div className="buttonBackground"><Link to={'faqs'} className="link-yellow">FAQs</Link></div>
                    <div className="buttonBackground"><Link to={'search'} className="link-green">SEARCH</Link></div>
                    <div className="buttonBackground"><Link to={'about-the-studio'} className="link-red">ABOUT THE STUDIO</Link></div>
                    <div className="buttonBackground"><Link to={'about-index'} className="link-yellow">ABOUT INDEX</Link></div>
                    <div className="buttonBackground"><Link to={'about-us'} className="link-green">ABOUT US</Link></div>
                    <div className="buttonBackground"><Link to={'contact-us'} className="link-red">CONTACT US</Link></div>
                </div>
            );
        }
    });
    return MainMenu;
});


/*
 <div className="sidebar-links">
 <div className="buttonBackground"><ReactRouter.Link to="index" onClick={this.handleClick(Index)} className="link-blue">HOME</ReactRouter.Link></div>
 <div className="buttonBackground"><a href="register" onClick={this.handleClick(Register)}  className="link-red">REGISTER</a></div>
 <div className="buttonBackground"><a href="faqs" onClick={this.handleClick(Faqs)}  className="link-yellow">FAQs</a></div>
 <div className="buttonBackground"><a href="search"  onClick={this.handleClick(Search)} className="link-green">SEARCH</a></div>
 <div className="buttonBackground"><a href="about-the-studio"  onClick={this.handleClick(AboutTheStudio)} className="link-red">ABOUT THE STUDIO</a></div>
 <div className="buttonBackground"><a href="about-index"  onClick={this.handleClick(AboutIndex)} className="link-yellow">ABOUT INDEX</a></div>
 <div className="buttonBackground"><a href="about-us"  onClick={this.handleClick(AboutUs)} className="link-green">ABOUT US</a></div>
 <div className="buttonBackground"><a href="contact-us"  onClick={this.handleClick(ContactUs)} className="link-red">CONTACT US</a></div>
 </div>
 */
