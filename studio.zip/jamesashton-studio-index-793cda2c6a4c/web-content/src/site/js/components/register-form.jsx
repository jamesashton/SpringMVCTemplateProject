/**
 * Created by james on 05/08/2016.
 */

define(function(require) {

    var React = require('react');
    var RegisterForm = React.createClass({
        render:function(){
            return (
                <div className="contact-us-form">
                    <div className="form-item">
                        <div className="form-label">First name</div>
                        <div className="form-value"><input ref="firstName" type="text" className="form-text-input" defaultValue={ this.props.registrationData.firstName} /></div>
                    </div>
                    <div className="form-item">
                        <div className="form-label">Last name</div>
                        <div className="form-value"><input ref="lastName" type="text" className="form-text-input" defaultValue={ this.props.registrationData.lastName}  /></div>
                    </div>
                    <div className="form-item">
                        <div className="form-label">Password</div>
                        <div className="form-value"><input ref="password" type="text" className="form-text-input" defaultValue={ this.props.registrationData.password}  /></div>
                    </div>
                    <div className="form-item">
                        <div className="form-label">Email</div>
                        <div className="form-value"><input ref="email" type="text" className="form-text-input" defaultValue={ this.props.registrationData.email} /></div>
                    </div>
                    <div className="form-item">
                        <button type="button" onClick={ this.saveAndContinue } className="form-submit-button">Continue</button>
                    </div>
                </div>
            );
        },
        saveAndContinue: function(e) {
            e.preventDefault();

            var data = {
                firstName: this.refs.firstName.value,
                lastName: this.refs.lastName.value,
                email: this.refs.email.value,
                password: this.refs.password.value
            };

            this.props.saveValues(data);
            this.props.nextStep();
        }
    });

    return RegisterForm;
});
