/**
 * Created by james on 05/08/2016.
 */

define(function(require) {

    var React = require('react');
    var RegisterFail = React.createClass({
        render:function(){
            return (
                <div className="contact-us-form">
                    <div className="form-item">
                        <div className="form-label">Success</div>
                        <div className="form-value"></div>
                    </div>
                </div>
            );
        }
    });

    return RegisterFail;
});
