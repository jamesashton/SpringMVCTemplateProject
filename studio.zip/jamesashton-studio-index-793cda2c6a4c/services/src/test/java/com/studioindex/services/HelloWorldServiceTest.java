package com.studioindex.services;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by james on 21/11/2016.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/services-test-context.xml" })
public class HelloWorldServiceTest {

    @Autowired
    HelloWorldService helloWorldService;

    @Test
    public void sayHelloTest() {
        Assert.assertTrue(helloWorldService.greetUser("bob").equals("HI THERE BOB"));
    }

}
