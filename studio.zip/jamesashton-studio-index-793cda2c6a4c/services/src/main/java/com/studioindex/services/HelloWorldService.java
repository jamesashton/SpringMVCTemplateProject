package com.studioindex.services;

/**
 * Created by james on 21/11/2016.
 */
public interface HelloWorldService {
    String greetUser(String text);
}
