package com.studioindex.services;

/**
 * Created by james on 21/11/2016.
 */

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

public class HelloWorldServiceImpl implements HelloWorldService {

    public String greetUser(String text) {
        return "HI THERE " + text.toUpperCase();
    }
}
