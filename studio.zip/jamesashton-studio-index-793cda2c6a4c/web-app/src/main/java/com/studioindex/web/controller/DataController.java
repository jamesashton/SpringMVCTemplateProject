package com.studioindex.web.controller;

import com.studioindex.web.model.*;
import com.studioindex.services.HelloWorldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * Created by james on 28/08/2016.
 */
@RestController
@RequestMapping("/data/")
public class DataController {

    @Autowired
    private HelloWorldService helloWorldService;

    @RequestMapping(value = "/{searchString}", method = RequestMethod.GET)
    public String getGreeting(@PathVariable String searchString) {
        String result = helloWorldService.greetUser(searchString);
        return result;

    }

    @RequestMapping(value = "/{searchString}/search.json", method=RequestMethod.GET)
    public Item getItem(@PathVariable String searchString) {
        Item item = new Item();
        item.setDate1(new Date());
        item.setNum1(1234);
        item.setString1("HELLO EVERYBODY");
        item.setString2("Hi there \"everybody\" hope you are well.");

        return item;
    }


    public HelloWorldService getHelloWorldService() {
        return helloWorldService;
    }

    public void setHelloWorldService(HelloWorldService helloWorldService) {
        this.helloWorldService = helloWorldService;
    }
}
