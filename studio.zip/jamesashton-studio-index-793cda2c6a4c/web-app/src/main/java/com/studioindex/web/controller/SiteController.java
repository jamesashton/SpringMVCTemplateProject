package com.studioindex.web.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by james on 28/08/2016.
 */
@Controller
public class SiteController {

    @RequestMapping(value={"/about-index","/about-the-studio","/about-us","/contact-us","/faqs","/index","/register","/search"})
    public String defaultPage(ModelMap model) {
        return "template";
    }

    @RequestMapping("/login")
    public String loginPage(ModelMap model) {
        String title = "Login Page";
        model.addAttribute("title",title);
        return "login";
    }

    @RequestMapping(value="/logout")
    public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/";
    }

    @RequestMapping(value = "/denied")
    public String accessDeniedPage(ModelMap model) {
        String title = "About Us";
        model.addAttribute("user", getPrincipal());
        model.addAttribute("title", title);
        return "denied";
    }

    private String getPrincipal(){
        String userName = null;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof UserDetails) {
            userName = ((UserDetails)principal).getUsername();
        } else {
            userName = principal.toString();
        }
        return userName;
    }

}
