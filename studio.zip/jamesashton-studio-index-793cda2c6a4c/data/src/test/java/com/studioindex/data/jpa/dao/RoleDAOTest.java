package com.studioindex.data.jpa.dao;

import com.studioindex.data.domain.Role;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by james on 11/12/2016.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/dao-test-context.xml" })
public class RoleDAOTest extends DAOTestBase {

    @Autowired
    RoleDAO roleDAO;

    @Test
    public void testThatGetAllRolesReturnsAnEmptyCollectionWhenNoRolesExist() {
        Assert.assertEquals("Test that GetAllRoles returns an empty collection before roles have been added.",roleDAO.getAllRoles().size(),0);
    }
    @Test
    public void testAddRoleCorrectlyPersistsObject() {

        Role role = new Role("Subscribers");
        roleDAO.addRole(role);

        Role roleFromDb = entityManager.find(Role.class,role.getId());

        Assert.assertEquals(role.getId(),roleFromDb.getId());
        Assert.assertEquals("Subscribers",roleFromDb.getName());

    }
}
