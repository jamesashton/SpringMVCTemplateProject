package com.studioindex.data.jpa.dao;

/**
 * Created by james on 05/12/2016.
 */

import com.studioindex.data.domain.Role;
import com.studioindex.data.domain.UserDetail;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import java.util.Arrays;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/dao-test-context.xml" })
public class UserDetailDAOTest extends DAOTestBase {

    @Autowired
    UserDetailDAO userDetailDAO;

    @Autowired
    RoleDAO roleDAO;

    @Test
    public void testGetAllUsersWhenNoUsersExist() {
        Assert.assertEquals("Test that GetAllUsers returns an empty collection before users have been added.",userDetailDAO.getAllUsers().size(),0);
    }

    @Test
    public void testAddUserCorrectlyPersistsObject() {
        //To Mock the Role stuff
        Role role = new Role("Subscribers");
        roleDAO.addRole(role);

        UserDetail userDetail = new UserDetail("jamesashton","James Ashton","James","Ashton","james@akanet.co.uk","password123", Arrays.asList(role) );
        userDetailDAO.addUser(userDetail);

        UserDetail userFromDb = entityManager.find(UserDetail.class,userDetail.getId());

        Assert.assertEquals("jamesashton",userFromDb.getUsername());
        Assert.assertEquals("James Ashton",userFromDb.getDisplayName());
        Assert.assertEquals("James",userFromDb.getFirstName());
        Assert.assertEquals("Ashton",userFromDb.getLastName());
        Assert.assertEquals("james@akanet.co.uk",userFromDb.getEmail());
        Assert.assertEquals("password123",userFromDb.getPassword());
        Assert.assertEquals(userDetail.getId(),userFromDb.getId());

    }

}
