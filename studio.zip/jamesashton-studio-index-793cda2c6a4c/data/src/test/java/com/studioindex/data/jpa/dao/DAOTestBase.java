package com.studioindex.data.jpa.dao;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import javax.persistence.*;

/**
 * Created by james on 05/12/2016.
 */
public abstract class DAOTestBase {

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    @PersistenceContext
    protected EntityManager entityManager;

    @BeforeClass
    public static void before() {
         }

    @AfterClass
    public static void after() {

    }

    @Before
    public void beginTransaction() {
        entityManagerFactory = Persistence.createEntityManagerFactory("persistenceUnit");
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
    }

    @After
    public void rollbackTransaction() {
        if (entityManager.getTransaction().isActive()) {
            entityManager.getTransaction().rollback();
        }

        if (entityManager.isOpen()) {
            entityManager.close();
        }
        entityManagerFactory.close();
    }
}