package com.studioindex.data.jpa.dao;
import com.studioindex.data.domain.Role;

import java.util.List;

/**
 * Created by james on 11/12/2016.
 */
public interface RoleDAO {
    List<Role> getAllRoles();
    Role getRoleById(Long id);
    void addRole(Role role);
}
