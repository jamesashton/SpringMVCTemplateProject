package com.studioindex.data.jpa.dao;

import com.studioindex.data.domain.Role;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import java.util.List;

/**
 * Created by james on 11/12/2016.
 */
@Repository
@Transactional
public class RoleDAOImpl implements RoleDAO {

    @PersistenceContext
    private EntityManager manager;

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public List<Role> getAllRoles() {
        List<Role> resultList = manager.createQuery("Select a From Role a", Role.class).getResultList();
        return resultList;
    }

    public Role getRoleById(Long id) {
        return manager.find(Role.class,id);
    }

    public void addRole(Role role) {
        manager.persist(role);
    }
}
