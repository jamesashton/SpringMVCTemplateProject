package com.studioindex.data.domain;

import javax.persistence.*;
import java.util.List;

/**
 * Created by james on 04/12/2016.
 */
@Entity
public class Role {

    public Role() {}

    public Role(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @ManyToMany(mappedBy="roles")
    private List<UserDetail> userDetails;


    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
