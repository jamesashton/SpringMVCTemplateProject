package com.studioindex.data.jpa.dao;

import com.studioindex.data.domain.UserDetail;

import java.util.List;

/**
 * Created by james on 05/12/2016.
 */
public interface UserDetailDAO {
    List<UserDetail> getAllUsers();
    UserDetail getUserById(Long id);
    void addUser(UserDetail user);
}
