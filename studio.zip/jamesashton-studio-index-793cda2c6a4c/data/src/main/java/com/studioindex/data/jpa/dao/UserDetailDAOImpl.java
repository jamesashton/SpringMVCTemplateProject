package com.studioindex.data.jpa.dao;

import com.studioindex.data.domain.UserDetail;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import java.util.List;

/**
 * Created by james on 05/12/2016.
 */
@Repository
@Transactional
public class UserDetailDAOImpl implements UserDetailDAO {

    @PersistenceContext
    private EntityManager manager;

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public List<UserDetail> getAllUsers() {
        List<UserDetail> resultList = manager.createQuery("Select a From UserDetail a", UserDetail.class).getResultList();
        return resultList;
    }

    public UserDetail getUserById(Long id) {
        return manager.find(UserDetail.class,id);
    }

    public void addUser(UserDetail user) {
        manager.persist(user);
    }

}
