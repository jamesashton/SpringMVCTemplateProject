package com.studioindex.data.jpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.studioindex.data.domain.Role;
import com.studioindex.data.domain.UserDetail;

public class JpaTest {

	private EntityManager manager;

	public JpaTest(EntityManager manager) {
		this.manager = manager;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("persistenceUnit");
		EntityManager manager = factory.createEntityManager();
		JpaTest test = new JpaTest(manager);

		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		try {
			test.createUsers();
		} catch (Exception e) {
			e.printStackTrace();
		}
		tx.commit();

		test.listUsers();
		System.out.println(".. done");
	}

	private void createUsers() {
		int numOfUsers = manager.createQuery("Select a from UserDetail a",UserDetail.class).getResultList().size();
		if(numOfUsers == 0) {
			Role role = new Role("subscriber");
			List<Role> roles = new ArrayList<Role>(Arrays.asList(new Role[]{role}));
			UserDetail userDetail = new UserDetail("jamesashton","James Ashton","James","Ashton","james@akanet.co.uk","password123",roles);
			manager.persist(role);
			manager.persist(userDetail);
		}
	}

	private void listUsers() {
		List<UserDetail> resultList = manager.createQuery("Select a From UserDetail a", UserDetail.class).getResultList();
		System.out.println("num of users:" + resultList.size());
		for (UserDetail userDetail : resultList) {
			System.out.println("next userDetail: " + userDetail);
		}
	}


}
