package com.studioindex.data.domain;

import javax.persistence.*;
import java.util.List;

/**
 * Created by james on 30/11/2016.
 */

@Entity
public class UserDetail {

    public UserDetail() {}

    public UserDetail(String username, String displayName, String firstName, String lastName, String email, String password, List<Role> roles) {
        this.username = username;
        this.displayName = displayName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.roles = roles;
    }

    @Id
    @GeneratedValue
    private long id;

    private String username;

    @ManyToMany
    @JoinTable(
        name="UserRole",
        joinColumns=@JoinColumn(name="ROLE_ID", referencedColumnName="ID"),
        inverseJoinColumns=@JoinColumn(name="USER_ID", referencedColumnName="ID"))
    private List<Role> roles;

    private String displayName;

    private String firstName;

    private String lastName;

    private String email;

    private String password;

    public String toString() {
        return "UserDetail [username=" + getUsername() + "]";
    }

    public long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
