mvn compile exec:java -Dexec.mainClass=com.studioindex.data.jpa.JpaTest
